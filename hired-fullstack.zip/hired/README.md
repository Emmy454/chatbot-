# HirED — My Campus to Career

A student-centred job portal built for a final-year project (FYP): trust & safety, AI-assisted
matching, gamification, and community features on a Node.js/Express + React + MySQL stack.

**What changed in this build:**
- Background is now pure white app-wide (see `frontend/src/styles/index.css` and the `surface` color in `tailwind.config.js`).
- All backend routes, middleware, utils (fraud detection, match engine, gamification), cron jobs, and the full React frontend (pages, components, auth context, API client) have been written — previously only config files existed.
- Added **Google** and **LinkedIn** "Continue with…" social sign-in (real OAuth via Passport.js).
- Added Framer Motion animations throughout: page transitions, hover/tap micro-interactions, animated Trust Ring, staggered card reveals, a mobile nav drawer, and a floating chatbot widget.

**A note on Indeed:** Indeed does not publish a public "Sign in with Indeed" OAuth API for third-party
sites, so a real login button isn't possible there. The Indeed button in the UI is shown disabled with
an honest tooltip instead of silently failing. Indeed integration that *is* real: job cross-posting
support already in the schema (`jobs.source`, `jobs.external_url`) — wiring that up requires applying
for Indeed's employer/publisher API separately.

## Stack
- **Frontend:** React (Vite), Tailwind CSS, Framer Motion, React Router, Axios, react-hot-toast, PWA support
- **Backend:** Node.js, Express (ES Modules), JWT auth + Google/LinkedIn OAuth (Passport.js), MySQL (mysql2), node-cron, nodemailer
- **Database:** MySQL 8

## Project structure
```
hired/
├── backend/
│   ├── schema.sql
│   ├── .env.example
│   └── src/
│       ├── config/        db.js, passport.js (Google/LinkedIn strategies)
│       ├── middleware/     auth.js (JWT), errorHandler.js
│       ├── routes/         one file per feature domain
│       ├── utils/          fraudDetection.js, matchEngine.js, gamification.js, seed.js, email.js, helpers.js
│       ├── jobs/            scheduledJobs.js (cron: reminders + digests)
│       ├── app.js, server.js
└── frontend/
    └── src/
        ├── api/client.js         axios instance with JWT interceptor
        ├── context/AuthContext.jsx
        ├── components/            Navbar, JobCard, TrustRing, ChatbotWidget, Footer, SocialAuthButtons, ProtectedRoute
        ├── pages/                 Home, Jobs, JobDetail, Login, Register, Dashboard, Forum, OAuthCallback
        └── styles/index.css
```

## Getting started

### 1. Prerequisites
- Node.js 18+
- MySQL 8 running locally (or update `.env` to point at a remote instance)

### 2. Database
```bash
mysql -u root -p < backend/schema.sql
```
This creates the `hired_db` database and all tables, plus seed reference data (badges, forum categories, chatbot FAQs).

### 3. Backend
```bash
cd backend
cp .env.example .env       # fill in DB credentials + JWT_SECRET (see below)
npm install
npm run seed                # optional: loads demo users/companies/jobs
npm run dev                 # starts on http://localhost:5000
```

Generate a strong `JWT_SECRET`:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

### 4. Frontend
```bash
cd frontend
npm install
npm run dev                 # starts on http://localhost:5173, proxies /api to :5000
```
Open http://localhost:5173.

### 5. (Optional) Google & LinkedIn sign-in
Leave `GOOGLE_CLIENT_ID`/`LINKEDIN_CLIENT_ID` blank in `.env` and those buttons simply won't be wired
up server-side (the frontend buttons still render for the demo, but clicking them will hit a 404 until
you configure real credentials). To enable them:

**Google:**
1. Go to https://console.cloud.google.com/apis/credentials
2. Create an OAuth Client ID (type: Web application)
3. Authorized redirect URI: `http://localhost:5000/api/auth/google/callback`
4. Copy the client ID/secret into `.env`

**LinkedIn:**
1. Go to https://www.linkedin.com/developers/apps
2. Create an app, request the "Sign In with LinkedIn" product
3. Redirect URL: `http://localhost:5000/api/auth/linkedin/callback`
4. Copy the client ID/secret into `.env`

Restart the backend after adding credentials.

### 6. (Optional) Digest emails
Fill in `SMTP_USER`/`SMTP_PASS` in `.env` (a Gmail App Password works) to enable the deadline-reminder
and job-alert-digest cron emails. Without it, the backend just logs what *would* have been sent.

## Demo logins (after `npm run seed`)
- Admin: `admin@hired.ng` / `Password123`
- Employer: `hr@zenithdigital.ng` / `Password123`
- Candidate: `chidera@student.futo.edu.ng` / `Password123`

## Feature → implementation map (for your Chapter 3/4 write-up)

| Feature | Where it lives | Notes |
|---|---|---|
| Employer verification | `companies.routes.js` | Doc submission → admin approve/reject workflow |
| Fraud/scam detection | `utils/fraudDetection.js` | Rule-based, explainable 0–100 risk score; auto-flags high-risk jobs |
| Report/flag system | `reports.routes.js` | Generic reports on job/review/user/company; auto-flags at 3+ reports |
| Reviews & moderation | `reviews.routes.js` | Pending → admin approve/reject; approved reviews feed company trust_score |
| AI-assisted job matching | `utils/matchEngine.js` | Weighted skill/location/experience/history overlap scoring (0–100) |
| "Similar jobs" | `matchEngine.js` + `job_views` table | `findSimilarJobs()`, `GET /api/jobs/:id` |
| Chatbot (FAQ) | `chatbot.routes.js` | Keyword-intent matching against `chatbot_faqs` table |
| Gamification | `utils/gamification.js` | Profile completion %, badge auto-award |
| Community forums | `forum.routes.js` | Categories → threads → replies |
| Deadline reminders | `jobs/scheduledJobs.js` | Hourly cron checks `reminders` table |
| Job alert digest emails | `jobs/scheduledJobs.js` | Daily/weekly cron, keyword+location match |
| Featured/sponsored jobs | `jobs.is_featured` | Sorted first in listings |
| Referral program | `auth.routes.js`, `misc.routes.js` | Referral code on signup, tracked in `referrals` |
| Messaging | `messages.routes.js` | Conversations auto-created on application |
| Verified badges | `companies.verification_status`, `users.is_verified` | Rendered via `TrustRing` |
| Google / LinkedIn sign-in | `config/passport.js`, `auth.routes.js` | Real OAuth; falls back gracefully if not configured |
| Indeed sign-in | `auth.routes.js` (`/api/auth/indeed`) | Not possible — no public OAuth API from Indeed; documented, not faked |
| PWA support | `vite.config.js` (vite-plugin-pwa) | Manifest + service worker, installable |
| Multi-language (scaffold) | `users.preferred_language` | Field present; UI i18n library not yet wired |
| LinkedIn/Indeed cross-posting | `jobs.source`, `jobs.external_url` | Schema ready; partner API integration is future work |

## Still worth doing next
- Resume/file uploads (multer is installed but no upload route is wired yet — add one to `users.routes.js`)
- Real-time messaging (currently polling-friendly REST; swap in Socket.IO if you want live chat)
- i18n library for `preferred_language`
- Admin UI pages (the API endpoints for admin exist in `misc.routes.js`/`reports.routes.js`/`reviews.routes.js`, but there's no dedicated admin dashboard page in the frontend yet)
