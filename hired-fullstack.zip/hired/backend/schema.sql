-- ============================================================
-- HirED Database Schema
-- "My Campus to Career"
-- ============================================================

CREATE DATABASE IF NOT EXISTS hired_db;
USE hired_db;

-- ============================================================
-- USERS & AUTH
-- ============================================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('candidate','employer','admin') NOT NULL DEFAULT 'candidate',
    phone VARCHAR(30),
    avatar_url VARCHAR(255),
    is_verified BOOLEAN DEFAULT FALSE,          -- verified candidate/employer badge
    is_active BOOLEAN DEFAULT TRUE,
    profile_completion INT DEFAULT 0,            -- gamification %
    referral_code VARCHAR(20) UNIQUE,
    referred_by INT NULL,
    preferred_language VARCHAR(10) DEFAULT 'en',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (referred_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Candidate profile detail
CREATE TABLE candidate_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    headline VARCHAR(150),
    bio TEXT,
    location VARCHAR(150),
    experience_level ENUM('entry','junior','mid','senior','executive') DEFAULT 'entry',
    years_experience INT DEFAULT 0,
    resume_url VARCHAR(255),
    skills JSON,                -- ["JavaScript","React","SQL"]
    portfolio_url VARCHAR(255),
    linkedin_url VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Employer/company profile
CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    website VARCHAR(255),
    industry VARCHAR(100),
    location VARCHAR(150),
    logo_url VARCHAR(255),
    verification_status ENUM('unverified','pending','verified','rejected') DEFAULT 'unverified',
    verification_docs_url VARCHAR(255),
    verified_at TIMESTAMP NULL,
    verified_by INT NULL,
    trust_score DECIMAL(4,2) DEFAULT 0.00,   -- derived from reviews + fraud checks
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- BADGES / GAMIFICATION
-- ============================================================
CREATE TABLE badges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,     -- e.g. PROFILE_COMPLETE, FIRST_APPLICATION
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    icon VARCHAR(100)
);

CREATE TABLE user_badges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    badge_id INT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_badge (user_id, badge_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (badge_id) REFERENCES badges(id) ON DELETE CASCADE
);

-- ============================================================
-- JOBS
-- ============================================================
CREATE TABLE jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    posted_by INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    requirements TEXT,
    skills_required JSON,             -- ["Node.js","MySQL"]
    location VARCHAR(150),
    is_remote BOOLEAN DEFAULT FALSE,
    job_type ENUM('internship','part-time','full-time','contract','nysc') DEFAULT 'full-time',
    experience_level ENUM('entry','junior','mid','senior','executive') DEFAULT 'entry',
    salary_min DECIMAL(12,2),
    salary_max DECIMAL(12,2),
    application_deadline DATE,
    status ENUM('draft','open','closed','flagged','removed') DEFAULT 'open',
    is_featured BOOLEAN DEFAULT FALSE,        -- sponsored/featured listing
    featured_until DATE NULL,
    fraud_score DECIMAL(5,2) DEFAULT 0.00,    -- 0-100 heuristic risk score
    source ENUM('native','linkedin','indeed') DEFAULT 'native',
    external_url VARCHAR(255) NULL,           -- for cross-posted jobs
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (posted_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_location (location),
    FULLTEXT idx_search (title, description)
);

-- Track which jobs a user viewed -> "Because you viewed X"
CREATE TABLE job_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    job_id INT NOT NULL,
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

CREATE TABLE saved_jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_id INT NOT NULL,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_save (user_id, job_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

-- ============================================================
-- APPLICATIONS
-- ============================================================
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    candidate_id INT NOT NULL,
    cover_letter TEXT,
    resume_url VARCHAR(255),
    status ENUM('submitted','viewed','shortlisted','interview','rejected','hired','withdrawn') DEFAULT 'submitted',
    match_score DECIMAL(5,2) DEFAULT 0.00,   -- skill/location/experience overlap score
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_application (job_id, candidate_id),
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Reminders for deadlines
CREATE TABLE reminders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_id INT NOT NULL,
    remind_at DATETIME NOT NULL,
    sent BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

-- ============================================================
-- REVIEWS & MODERATION
-- ============================================================
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    user_id INT NOT NULL,
    rating DECIMAL(2,1) NOT NULL,      -- 1.0 - 5.0
    title VARCHAR(150),
    body TEXT,
    pros TEXT,
    cons TEXT,
    is_anonymous BOOLEAN DEFAULT TRUE,
    status ENUM('pending','approved','rejected','flagged') DEFAULT 'pending',
    moderated_by INT NULL,
    moderated_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (moderated_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- REPORTS / FLAGGING (generic - jobs, reviews, users)
-- ============================================================
CREATE TABLE reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reporter_id INT NOT NULL,
    target_type ENUM('job','review','user','company') NOT NULL,
    target_id INT NOT NULL,
    reason ENUM('scam','spam','inappropriate','fake_company','misleading','other') NOT NULL,
    details TEXT,
    status ENUM('open','reviewing','resolved','dismissed') DEFAULT 'open',
    resolved_by INT NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_target (target_type, target_id)
);

-- ============================================================
-- MESSAGING
-- ============================================================
CREATE TABLE conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NULL,
    candidate_id INT NOT NULL,
    employer_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_conv (job_id, candidate_id, employer_id),
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL,
    FOREIGN KEY (candidate_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT NOT NULL,
    sender_id INT NOT NULL,
    body TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- FORUMS / COMMUNITY
-- ============================================================
CREATE TABLE forum_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description VARCHAR(255)
);

CREATE TABLE forum_threads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    is_pinned BOOLEAN DEFAULT FALSE,
    is_locked BOOLEAN DEFAULT FALSE,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES forum_categories(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE forum_replies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    thread_id INT NOT NULL,
    user_id INT NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (thread_id) REFERENCES forum_threads(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- CHATBOT (FAQ / assisted help)
-- ============================================================
CREATE TABLE chatbot_faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    intent VARCHAR(100) NOT NULL,       -- e.g. "how_to_apply"
    keywords JSON,                       -- ["apply","application","how do i apply"]
    answer TEXT NOT NULL,
    category VARCHAR(50)
);

CREATE TABLE chatbot_conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    session_id VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    sender ENUM('user','bot') NOT NULL,
    matched_intent VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- REFERRALS / AFFILIATE
-- ============================================================
CREATE TABLE referrals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    referrer_id INT NOT NULL,
    referred_id INT NOT NULL,
    status ENUM('pending','completed','rewarded') DEFAULT 'pending',
    reward_points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (referred_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- JOB ALERTS / DIGEST EMAILS
-- ============================================================
CREATE TABLE job_alert_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    keywords VARCHAR(255),
    location VARCHAR(150),
    frequency ENUM('daily','weekly','off') DEFAULT 'weekly',
    last_sent_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- AUDIT LOG (admin actions, fraud flags etc.)
-- ============================================================
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    actor_id INT NULL,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id INT,
    details JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- SEED DATA
-- ============================================================
INSERT INTO badges (code, name, description, icon) VALUES
('PROFILE_COMPLETE', 'Profile Pro', 'Completed 100% of your profile', 'star'),
('FIRST_APPLICATION', 'First Steps', 'Submitted your first application', 'flag'),
('VERIFIED_CANDIDATE', 'Verified', 'Identity verified', 'shield-check'),
('FIVE_APPLICATIONS', 'Go-Getter', 'Applied to 5 jobs', 'zap'),
('FIRST_REVIEW', 'Voice Heard', 'Left your first company review', 'message-square'),
('COMMUNITY_HELPER', 'Community Helper', 'Answered a forum question', 'users');

INSERT INTO forum_categories (name, slug, description) VALUES
('Interview Tips', 'interview-tips', 'Share and get interview advice'),
('Resume Help', 'resume-help', 'CV and resume feedback'),
('Internships & NYSC', 'internships-nysc', 'Internship and NYSC placement discussion'),
('Career Advice', 'career-advice', 'General career guidance');

INSERT INTO chatbot_faqs (intent, keywords, answer, category) VALUES
('how_to_apply', '["apply","application","how do i apply","submit application"]', 'To apply, open a job listing and click "Apply Now". You can attach your resume and a cover letter before submitting.', 'applications'),
('edit_profile', '["edit profile","update profile","change my info"]', 'Go to your Dashboard > Profile to update your details, skills, and resume.', 'profile'),
('verification', '["verify","verification","verified badge"]', 'Employers get verified by submitting company registration documents in Dashboard > Company > Verification. Candidates can verify identity in Profile > Verification.', 'trust'),
('report_scam', '["scam","fraud","report job","fake job"]', 'You can report any suspicious listing by clicking "Report" on the job page. Our trust & safety team reviews all reports within 24 hours.', 'trust'),
('application_status', '["status","track application","where is my application"]', 'Check Dashboard > My Applications to see real-time status updates for every job you have applied to.', 'applications');
