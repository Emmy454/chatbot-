import cron from 'node-cron';
import { query } from '../config/db.js';
import { sendEmail } from '../utils/email.js';
import { safeJsonParse } from '../utils/helpers.js';

// Hourly: deadline reminders
function startDeadlineReminders() {
  cron.schedule('0 * * * *', async () => {
    try {
      const due = await query(
        `SELECT r.*, u.email, u.full_name, j.title FROM reminders r
         JOIN users u ON u.id = r.user_id JOIN jobs j ON j.id = r.job_id
         WHERE r.sent = FALSE AND r.remind_at <= NOW()`
      );
      for (const r of due) {
        await sendEmail({
          to: r.email,
          subject: `Reminder: deadline approaching for ${r.title}`,
          html: `<p>Hi ${r.full_name}, the application deadline for <b>${r.title}</b> is coming up. Don't miss it!</p>`,
        });
        await query('UPDATE reminders SET sent = TRUE WHERE id = ?', [r.id]);
      }
    } catch (err) {
      console.error('Deadline reminder job failed:', err.message);
    }
  });
}

// Daily at 8am: job alert digest emails (keyword + location match)
function startDigestEmails() {
  cron.schedule('0 8 * * *', async () => {
    try {
      const prefs = await query(
        `SELECT p.*, u.email, u.full_name FROM job_alert_preferences p
         JOIN users u ON u.id = p.user_id
         WHERE p.frequency != 'off'
         AND (p.last_sent_at IS NULL
              OR (p.frequency = 'daily' AND p.last_sent_at < NOW() - INTERVAL 1 DAY)
              OR (p.frequency = 'weekly' AND p.last_sent_at < NOW() - INTERVAL 7 DAY))`
      );

      for (const pref of prefs) {
        const params = [];
        let sql = `SELECT j.*, c.name AS company_name FROM jobs j JOIN companies c ON c.id = j.company_id
                   WHERE j.status = 'open' AND j.created_at > NOW() - INTERVAL 7 DAY`;
        if (pref.keywords) { sql += ' AND (j.title LIKE ? OR j.description LIKE ?)'; params.push(`%${pref.keywords}%`, `%${pref.keywords}%`); }
        if (pref.location) { sql += ' AND j.location LIKE ?'; params.push(`%${pref.location}%`); }
        sql += ' ORDER BY j.created_at DESC LIMIT 10';

        const matches = await query(sql, params);
        if (!matches.length) continue;

        const list = matches.map((m) => `<li>${m.title} — ${m.company_name} (${m.location || 'Remote'})</li>`).join('');
        await sendEmail({
          to: pref.email,
          subject: `${matches.length} new jobs matching your alert`,
          html: `<p>Hi ${pref.full_name}, here's what's new:</p><ul>${list}</ul>`,
        });
        await query('UPDATE job_alert_preferences SET last_sent_at = NOW() WHERE id = ?', [pref.id]);
      }
    } catch (err) {
      console.error('Digest email job failed:', err.message);
    }
  });
}

export function startScheduledJobs() {
  startDeadlineReminders();
  startDigestEmails();
  console.log('Scheduled jobs started: hourly deadline reminders, daily digest emails.');
}
