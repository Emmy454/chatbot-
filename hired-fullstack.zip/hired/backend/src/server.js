import app from './app.js';
import dotenv from 'dotenv';
import { startScheduledJobs } from './jobs/scheduledJobs.js';

dotenv.config();
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`HirED API running on http://localhost:${PORT}`);
  startScheduledJobs();
});
