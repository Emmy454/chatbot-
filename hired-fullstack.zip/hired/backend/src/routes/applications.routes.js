import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { computeMatchScore } from '../utils/matchEngine.js';
import { evaluateAndAwardBadges } from '../utils/gamification.js';

const router = Router();

// Candidate applies to a job
router.post('/', requireAuth, requireRole('candidate'), asyncHandler(async (req, res) => {
  const { jobId, coverLetter, resumeUrl } = req.body;
  const jobs = await query('SELECT * FROM jobs WHERE id = ? AND status = "open"', [jobId]);
  if (!jobs.length) return res.status(404).json({ error: 'Job not found or no longer accepting applications.' });

  const existing = await query('SELECT id FROM applications WHERE job_id = ? AND candidate_id = ?', [jobId, req.user.id]);
  if (existing.length) return res.status(409).json({ error: 'You have already applied to this job.' });

  const profiles = await query('SELECT * FROM candidate_profiles WHERE user_id = ?', [req.user.id]);
  const matchScore = await computeMatchScore(profiles[0], jobs[0], req.user.id);

  const result = await query(
    `INSERT INTO applications (job_id, candidate_id, cover_letter, resume_url, match_score)
     VALUES (?,?,?,?,?)`,
    [jobId, req.user.id, coverLetter, resumeUrl || profiles[0]?.resume_url, matchScore]
  );

  // Auto-create a conversation thread for messaging
  await query(
    `INSERT IGNORE INTO conversations (job_id, candidate_id, employer_id) VALUES (?, ?, ?)`,
    [jobId, req.user.id, jobs[0].posted_by]
  );

  const newBadges = await evaluateAndAwardBadges(req.user.id);
  const applications = await query('SELECT * FROM applications WHERE id = ?', [result.insertId]);
  res.status(201).json({ application: applications[0], newBadges });
}));

// Candidate: my applications
router.get('/mine', requireAuth, requireRole('candidate'), asyncHandler(async (req, res) => {
  const apps = await query(
    `SELECT a.*, j.title, j.location, c.name AS company_name FROM applications a
     JOIN jobs j ON j.id = a.job_id JOIN companies c ON c.id = j.company_id
     WHERE a.candidate_id = ? ORDER BY a.applied_at DESC`,
    [req.user.id]
  );
  res.json({ applications: apps });
}));

// Employer: applications for a given job
router.get('/job/:jobId', requireAuth, requireRole('employer'), asyncHandler(async (req, res) => {
  const jobs = await query('SELECT * FROM jobs WHERE id = ? AND posted_by = ?', [req.params.jobId, req.user.id]);
  if (!jobs.length) return res.status(403).json({ error: 'You can only view applicants for your own jobs.' });

  const apps = await query(
    `SELECT a.*, u.full_name, u.email, u.avatar_url FROM applications a
     JOIN users u ON u.id = a.candidate_id WHERE a.job_id = ? ORDER BY a.match_score DESC`,
    [req.params.jobId]
  );
  res.json({ applications: apps });
}));

// Employer updates application status
router.put('/:id/status', requireAuth, requireRole('employer'), asyncHandler(async (req, res) => {
  const { status } = req.body;
  const valid = ['submitted', 'viewed', 'shortlisted', 'interview', 'rejected', 'hired'];
  if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status.' });

  const apps = await query(
    `SELECT a.* FROM applications a JOIN jobs j ON j.id = a.job_id WHERE a.id = ? AND j.posted_by = ?`,
    [req.params.id, req.user.id]
  );
  if (!apps.length) return res.status(403).json({ error: 'You can only update applicants for your own jobs.' });

  await query('UPDATE applications SET status = ? WHERE id = ?', [status, req.params.id]);
  res.json({ success: true });
}));

// Candidate withdraws
router.put('/:id/withdraw', requireAuth, requireRole('candidate'), asyncHandler(async (req, res) => {
  await query(
    `UPDATE applications SET status = 'withdrawn' WHERE id = ? AND candidate_id = ?`,
    [req.params.id, req.user.id]
  );
  res.json({ success: true });
}));

export default router;
