import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';

const router = Router();

router.get('/conversations', requireAuth, asyncHandler(async (req, res) => {
  const convos = await query(
    `SELECT c.*, j.title AS job_title,
      candU.full_name AS candidate_name, empU.full_name AS employer_name,
      (SELECT body FROM messages m WHERE m.conversation_id = c.id ORDER BY m.sent_at DESC LIMIT 1) AS last_message,
      (SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id AND m.is_read = FALSE AND m.sender_id != ?) AS unread_count
     FROM conversations c
     LEFT JOIN jobs j ON j.id = c.job_id
     JOIN users candU ON candU.id = c.candidate_id
     JOIN users empU ON empU.id = c.employer_id
     WHERE c.candidate_id = ? OR c.employer_id = ?
     ORDER BY c.id DESC`,
    [req.user.id, req.user.id, req.user.id]
  );
  res.json({ conversations: convos });
}));

router.get('/conversations/:id', requireAuth, asyncHandler(async (req, res) => {
  const convos = await query('SELECT * FROM conversations WHERE id = ?', [req.params.id]);
  if (!convos.length) return res.status(404).json({ error: 'Conversation not found.' });
  const convo = convos[0];
  if (convo.candidate_id !== req.user.id && convo.employer_id !== req.user.id) {
    return res.status(403).json({ error: 'You do not have access to this conversation.' });
  }
  const messages = await query(
    'SELECT * FROM messages WHERE conversation_id = ? ORDER BY sent_at ASC',
    [req.params.id]
  );
  await query(
    'UPDATE messages SET is_read = TRUE WHERE conversation_id = ? AND sender_id != ?',
    [req.params.id, req.user.id]
  );
  res.json({ conversation: convo, messages });
}));

router.post('/conversations/:id/messages', requireAuth, asyncHandler(async (req, res) => {
  const { body } = req.body;
  if (!body?.trim()) return res.status(400).json({ error: 'Message cannot be empty.' });
  const convos = await query('SELECT * FROM conversations WHERE id = ?', [req.params.id]);
  if (!convos.length) return res.status(404).json({ error: 'Conversation not found.' });
  const convo = convos[0];
  if (convo.candidate_id !== req.user.id && convo.employer_id !== req.user.id) {
    return res.status(403).json({ error: 'You do not have access to this conversation.' });
  }
  const result = await query(
    'INSERT INTO messages (conversation_id, sender_id, body) VALUES (?, ?, ?)',
    [req.params.id, req.user.id, body.trim()]
  );
  const messages = await query('SELECT * FROM messages WHERE id = ?', [result.insertId]);
  res.status(201).json({ message: messages[0] });
}));

export default router;
