import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { evaluateAndAwardBadges } from '../utils/gamification.js';

const router = Router();

router.get('/categories', asyncHandler(async (req, res) => {
  res.json({ categories: await query('SELECT * FROM forum_categories') });
}));

router.get('/categories/:slug/threads', asyncHandler(async (req, res) => {
  const cats = await query('SELECT * FROM forum_categories WHERE slug = ?', [req.params.slug]);
  if (!cats.length) return res.status(404).json({ error: 'Category not found.' });
  const threads = await query(
    `SELECT t.*, u.full_name, (SELECT COUNT(*) FROM forum_replies fr WHERE fr.thread_id = t.id) AS reply_count
     FROM forum_threads t JOIN users u ON u.id = t.user_id
     WHERE t.category_id = ? ORDER BY t.is_pinned DESC, t.created_at DESC`,
    [cats[0].id]
  );
  res.json({ category: cats[0], threads });
}));

router.get('/threads/:id', asyncHandler(async (req, res) => {
  const threads = await query(
    `SELECT t.*, u.full_name FROM forum_threads t JOIN users u ON u.id = t.user_id WHERE t.id = ?`,
    [req.params.id]
  );
  if (!threads.length) return res.status(404).json({ error: 'Thread not found.' });
  await query('UPDATE forum_threads SET views_count = views_count + 1 WHERE id = ?', [req.params.id]);
  const replies = await query(
    `SELECT fr.*, u.full_name FROM forum_replies fr JOIN users u ON u.id = fr.user_id
     WHERE fr.thread_id = ? ORDER BY fr.created_at ASC`,
    [req.params.id]
  );
  res.json({ thread: threads[0], replies });
}));

router.post('/categories/:slug/threads', requireAuth, asyncHandler(async (req, res) => {
  const { title, body } = req.body;
  if (!title || !body) return res.status(400).json({ error: 'Title and body are required.' });
  const cats = await query('SELECT * FROM forum_categories WHERE slug = ?', [req.params.slug]);
  if (!cats.length) return res.status(404).json({ error: 'Category not found.' });
  const result = await query(
    'INSERT INTO forum_threads (category_id, user_id, title, body) VALUES (?,?,?,?)',
    [cats[0].id, req.user.id, title, body]
  );
  res.status(201).json({ threadId: result.insertId });
}));

router.post('/threads/:id/replies', requireAuth, asyncHandler(async (req, res) => {
  const { body } = req.body;
  if (!body?.trim()) return res.status(400).json({ error: 'Reply cannot be empty.' });
  const threads = await query('SELECT * FROM forum_threads WHERE id = ?', [req.params.id]);
  if (!threads.length) return res.status(404).json({ error: 'Thread not found.' });
  if (threads[0].is_locked) return res.status(403).json({ error: 'This thread is locked.' });

  const result = await query(
    'INSERT INTO forum_replies (thread_id, user_id, body) VALUES (?,?,?)',
    [req.params.id, req.user.id, body.trim()]
  );
  const newBadges = await evaluateAndAwardBadges(req.user.id);
  res.status(201).json({ replyId: result.insertId, newBadges });
}));

export default router;
