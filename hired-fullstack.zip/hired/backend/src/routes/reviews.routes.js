import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { evaluateAndAwardBadges } from '../utils/gamification.js';

const router = Router();

async function recomputeTrustScore(companyId) {
  const rows = await query(
    `SELECT AVG(rating) avgRating FROM reviews WHERE company_id = ? AND status = 'approved'`,
    [companyId]
  );
  const companies = await query('SELECT fraud_flags FROM companies WHERE id = ?', [companyId]).catch(() => [{}]);
  const avg = rows[0].avgRating || 0;
  // Trust score blends review average (0-5 -> 0-100) with a placeholder fraud offset;
  // real fraud offset is computed per-job in fraudDetection.js and reflected via reports.
  const trust = Math.round((avg / 5) * 100 * 100) / 100;
  await query('UPDATE companies SET trust_score = ? WHERE id = ?', [trust, companyId]);
}

router.post('/', requireAuth, asyncHandler(async (req, res) => {
  const { companyId, rating, title, body, pros, cons, isAnonymous } = req.body;
  if (!companyId || !rating) return res.status(400).json({ error: 'Company and rating are required.' });

  const result = await query(
    `INSERT INTO reviews (company_id, user_id, rating, title, body, pros, cons, is_anonymous)
     VALUES (?,?,?,?,?,?,?,?)`,
    [companyId, req.user.id, rating, title, body, pros, cons, isAnonymous !== false]
  );
  const newBadges = await evaluateAndAwardBadges(req.user.id);
  res.status(201).json({ reviewId: result.insertId, status: 'pending', newBadges,
    message: 'Your review has been submitted and is awaiting moderation.' });
}));

router.get('/pending', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const reviews = await query(
    `SELECT r.*, u.full_name, c.name AS company_name FROM reviews r
     JOIN users u ON u.id = r.user_id JOIN companies c ON c.id = r.company_id
     WHERE r.status = 'pending' ORDER BY r.created_at ASC`
  );
  res.json({ reviews });
}));

router.put('/:id/moderate', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const { decision } = req.body; // approved | rejected
  if (!['approved', 'rejected'].includes(decision)) {
    return res.status(400).json({ error: 'Decision must be approved or rejected.' });
  }
  const reviews = await query('SELECT * FROM reviews WHERE id = ?', [req.params.id]);
  if (!reviews.length) return res.status(404).json({ error: 'Review not found.' });

  await query(
    'UPDATE reviews SET status = ?, moderated_by = ?, moderated_at = NOW() WHERE id = ?',
    [decision, req.user.id, req.params.id]
  );
  if (decision === 'approved') await recomputeTrustScore(reviews[0].company_id);
  res.json({ success: true });
}));

export default router;
