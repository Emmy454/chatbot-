import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { computeProfileCompletion, evaluateAndAwardBadges } from '../utils/gamification.js';
import { safeJsonParse } from '../utils/helpers.js';

const router = Router();

router.get('/me/profile', requireAuth, asyncHandler(async (req, res) => {
  const users = await query('SELECT * FROM users WHERE id = ?', [req.user.id]);
  const profiles = await query('SELECT * FROM candidate_profiles WHERE user_id = ?', [req.user.id]);
  const badges = await query(
    `SELECT b.* FROM user_badges ub JOIN badges b ON b.id = ub.badge_id WHERE ub.user_id = ?`,
    [req.user.id]
  );
  const profile = profiles[0] || null;
  if (profile) profile.skills = safeJsonParse(profile.skills);
  const { password_hash, ...user } = users[0];
  res.json({ user, profile, badges });
}));

router.put('/me/profile', requireAuth, asyncHandler(async (req, res) => {
  const { fullName, phone, avatarUrl, headline, bio, location, experienceLevel,
    yearsExperience, resumeUrl, skills, portfolioUrl, linkedinUrl } = req.body;

  await query(
    'UPDATE users SET full_name = COALESCE(?, full_name), phone = COALESCE(?, phone), avatar_url = COALESCE(?, avatar_url) WHERE id = ?',
    [fullName, phone, avatarUrl, req.user.id]
  );

  const existing = await query('SELECT id FROM candidate_profiles WHERE user_id = ?', [req.user.id]);
  const skillsJson = JSON.stringify(skills || []);
  if (existing.length) {
    await query(
      `UPDATE candidate_profiles SET headline=?, bio=?, location=?, experience_level=?,
       years_experience=?, resume_url=?, skills=?, portfolio_url=?, linkedin_url=? WHERE user_id=?`,
      [headline, bio, location, experienceLevel, yearsExperience || 0, resumeUrl, skillsJson, portfolioUrl, linkedinUrl, req.user.id]
    );
  } else {
    await query(
      `INSERT INTO candidate_profiles (user_id, headline, bio, location, experience_level,
       years_experience, resume_url, skills, portfolio_url, linkedin_url) VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [req.user.id, headline, bio, location, experienceLevel, yearsExperience || 0, resumeUrl, skillsJson, portfolioUrl, linkedinUrl]
    );
  }

  const completion = await computeProfileCompletion(req.user.id);
  const newBadges = await evaluateAndAwardBadges(req.user.id);
  res.json({ profileCompletion: completion, newBadges });
}));

router.get('/:id/public', asyncHandler(async (req, res) => {
  const users = await query(
    'SELECT id, full_name, avatar_url, is_verified, created_at FROM users WHERE id = ?',
    [req.params.id]
  );
  if (!users.length) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: users[0] });
}));

export default router;
