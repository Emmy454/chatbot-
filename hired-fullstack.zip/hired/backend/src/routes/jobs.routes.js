import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole, optionalAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { scoreJobFraudRisk, FRAUD_AUTO_FLAG_THRESHOLD } from '../utils/fraudDetection.js';
import { findSimilarJobs } from '../utils/matchEngine.js';

const router = Router();

// ---- List / search jobs ----
router.get('/', optionalAuth, asyncHandler(async (req, res) => {
  const { search, location, jobType, experienceLevel, remote, page = 1, limit = 20 } = req.query;
  const params = [];
  let sql = `SELECT j.*, c.name AS company_name, c.logo_url AS company_logo, c.verification_status
             FROM jobs j JOIN companies c ON c.id = j.company_id WHERE j.status = 'open'`;

  if (search) {
    sql += ' AND MATCH(j.title, j.description) AGAINST (? IN NATURAL LANGUAGE MODE)';
    params.push(search);
  }
  if (location) { sql += ' AND j.location LIKE ?'; params.push(`%${location}%`); }
  if (jobType) { sql += ' AND j.job_type = ?'; params.push(jobType); }
  if (experienceLevel) { sql += ' AND j.experience_level = ?'; params.push(experienceLevel); }
  if (remote === 'true') { sql += ' AND j.is_remote = TRUE'; }

  sql += ' ORDER BY j.is_featured DESC, j.created_at DESC LIMIT ? OFFSET ?';
  const lim = Math.min(Number(limit) || 20, 50);
  params.push(lim, (Number(page) - 1) * lim);

  const jobs = await query(sql, params);
  res.json({ jobs, page: Number(page), limit: lim });
}));

// ---- Single job (+ view tracking + similar jobs) ----
router.get('/:id', optionalAuth, asyncHandler(async (req, res) => {
  const jobs = await query(
    `SELECT j.*, c.name AS company_name, c.logo_url AS company_logo, c.verification_status,
      c.trust_score, c.website AS company_website
     FROM jobs j JOIN companies c ON c.id = j.company_id WHERE j.id = ?`,
    [req.params.id]
  );
  if (!jobs.length) return res.status(404).json({ error: 'Job not found.' });
  const job = jobs[0];

  await query('UPDATE jobs SET views_count = views_count + 1 WHERE id = ?', [job.id]);
  await query('INSERT INTO job_views (user_id, job_id) VALUES (?, ?)', [req.user?.id || null, job.id]);

  const similar = await findSimilarJobs(job, 6);
  res.json({ job, similarJobs: similar });
}));

// ---- Create job (employer) ----
router.post('/', requireAuth, requireRole('employer'), asyncHandler(async (req, res) => {
  const {
    companyId, title, description, requirements, skillsRequired, location, isRemote,
    jobType, experienceLevel, salaryMin, salaryMax, applicationDeadline, isFeatured,
  } = req.body;

  if (!title || !description || !companyId) {
    return res.status(400).json({ error: 'Title, description, and company are required.' });
  }

  const companies = await query('SELECT * FROM companies WHERE id = ? AND owner_id = ?', [companyId, req.user.id]);
  if (!companies.length) return res.status(403).json({ error: 'You can only post jobs for your own company.' });

  const result = await query(
    `INSERT INTO jobs (company_id, posted_by, title, description, requirements, skills_required,
      location, is_remote, job_type, experience_level, salary_min, salary_max,
      application_deadline, is_featured)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [companyId, req.user.id, title, description, requirements, JSON.stringify(skillsRequired || []),
      location, !!isRemote, jobType || 'full-time', experienceLevel || 'entry', salaryMin || null,
      salaryMax || null, applicationDeadline || null, !!isFeatured]
  );

  const jobs = await query('SELECT * FROM jobs WHERE id = ?', [result.insertId]);
  const { score, level, reasons } = scoreJobFraudRisk(jobs[0], companies[0]);

  let status = 'open';
  if (score >= FRAUD_AUTO_FLAG_THRESHOLD) status = 'flagged';
  await query('UPDATE jobs SET fraud_score = ?, status = ? WHERE id = ?', [score, status, result.insertId]);

  res.status(201).json({
    job: { ...jobs[0], fraud_score: score, status },
    fraudAssessment: { score, level, reasons },
  });
}));

router.put('/:id', requireAuth, requireRole('employer'), asyncHandler(async (req, res) => {
  const jobs = await query('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
  if (!jobs.length) return res.status(404).json({ error: 'Job not found.' });
  if (jobs[0].posted_by !== req.user.id) return res.status(403).json({ error: 'You can only edit your own job posts.' });

  const fields = ['title', 'description', 'requirements', 'location', 'job_type', 'experience_level',
    'salary_min', 'salary_max', 'application_deadline', 'status'];
  const updates = [];
  const params = [];
  fields.forEach((f) => {
    const camel = f.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    if (req.body[camel] !== undefined) {
      updates.push(`${f} = ?`);
      params.push(req.body[camel]);
    }
  });
  if (req.body.skillsRequired) {
    updates.push('skills_required = ?');
    params.push(JSON.stringify(req.body.skillsRequired));
  }
  if (!updates.length) return res.json({ success: true, message: 'Nothing to update.' });
  params.push(req.params.id);
  await query(`UPDATE jobs SET ${updates.join(', ')} WHERE id = ?`, params);
  res.json({ success: true });
}));

router.delete('/:id', requireAuth, requireRole('employer', 'admin'), asyncHandler(async (req, res) => {
  const jobs = await query('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
  if (!jobs.length) return res.status(404).json({ error: 'Job not found.' });
  if (jobs[0].posted_by !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'You can only remove your own job posts.' });
  }
  await query(`UPDATE jobs SET status = 'removed' WHERE id = ?`, [req.params.id]);
  res.json({ success: true });
}));

// ---- Save / unsave ----
router.post('/:id/save', requireAuth, asyncHandler(async (req, res) => {
  await query('INSERT IGNORE INTO saved_jobs (user_id, job_id) VALUES (?, ?)', [req.user.id, req.params.id]);
  res.json({ saved: true });
}));

router.delete('/:id/save', requireAuth, asyncHandler(async (req, res) => {
  await query('DELETE FROM saved_jobs WHERE user_id = ? AND job_id = ?', [req.user.id, req.params.id]);
  res.json({ saved: false });
}));

router.get('/saved/mine', requireAuth, asyncHandler(async (req, res) => {
  const jobs = await query(
    `SELECT j.*, c.name AS company_name FROM saved_jobs s
     JOIN jobs j ON j.id = s.job_id JOIN companies c ON c.id = j.company_id
     WHERE s.user_id = ? ORDER BY s.saved_at DESC`,
    [req.user.id]
  );
  res.json({ jobs });
}));

export default router;
