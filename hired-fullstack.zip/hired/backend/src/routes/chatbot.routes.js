import { Router } from 'express';
import { query } from '../config/db.js';
import { optionalAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { safeJsonParse } from '../utils/helpers.js';

const router = Router();

function scoreMatch(message, keywords) {
  const msg = message.toLowerCase();
  return keywords.reduce((score, kw) => (msg.includes(kw.toLowerCase()) ? score + kw.length : score), 0);
}

router.post('/message', optionalAuth, asyncHandler(async (req, res) => {
  const { message, sessionId } = req.body;
  if (!message?.trim()) return res.status(400).json({ error: 'Message cannot be empty.' });

  const faqs = await query('SELECT * FROM chatbot_faqs');
  let best = null;
  let bestScore = 0;
  faqs.forEach((faq) => {
    const kws = safeJsonParse(faq.keywords);
    const s = scoreMatch(message, kws);
    if (s > bestScore) { bestScore = s; best = faq; }
  });

  const answer = best
    ? best.answer
    : "I don't have an answer for that yet — try rephrasing, or ask about applying, verification, reporting a scam, or your application status. You can also post in the Community forum for help from other students.";

  await query(
    'INSERT INTO chatbot_conversations (user_id, session_id, message, sender, matched_intent) VALUES (?,?,?,"user",?)',
    [req.user?.id || null, sessionId || 'anon', message, best?.intent || null]
  );
  await query(
    'INSERT INTO chatbot_conversations (user_id, session_id, message, sender, matched_intent) VALUES (?,?,?,"bot",?)',
    [req.user?.id || null, sessionId || 'anon', answer, best?.intent || null]
  );

  res.json({ answer, matchedIntent: best?.intent || null });
}));

export default router;
