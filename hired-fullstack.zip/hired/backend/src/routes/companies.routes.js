import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';

const router = Router();

router.get('/', asyncHandler(async (req, res) => {
  const { search } = req.query;
  let sql = 'SELECT * FROM companies WHERE 1=1';
  const params = [];
  if (search) {
    sql += ' AND name LIKE ?';
    params.push(`%${search}%`);
  }
  sql += ' ORDER BY trust_score DESC LIMIT 50';
  res.json({ companies: await query(sql, params) });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const companies = await query('SELECT * FROM companies WHERE id = ?', [req.params.id]);
  if (!companies.length) return res.status(404).json({ error: 'Company not found.' });
  const reviews = await query(
    `SELECT r.*, u.full_name FROM reviews r JOIN users u ON u.id = r.user_id
     WHERE r.company_id = ? AND r.status = 'approved' ORDER BY r.created_at DESC LIMIT 20`,
    [req.params.id]
  );
  const jobs = await query(
    `SELECT * FROM jobs WHERE company_id = ? AND status = 'open' ORDER BY created_at DESC`,
    [req.params.id]
  );
  res.json({ company: companies[0], reviews, jobs });
}));

// Create a company profile (employer onboarding)
router.post('/', requireAuth, requireRole('employer'), asyncHandler(async (req, res) => {
  const { name, description, website, industry, location, logoUrl } = req.body;
  if (!name) return res.status(400).json({ error: 'Company name is required.' });

  const result = await query(
    `INSERT INTO companies (owner_id, name, description, website, industry, location, logo_url)
     VALUES (?,?,?,?,?,?,?)`,
    [req.user.id, name, description, website, industry, location, logoUrl]
  );
  const companies = await query('SELECT * FROM companies WHERE id = ?', [result.insertId]);
  res.status(201).json({ company: companies[0] });
}));

router.put('/:id', requireAuth, asyncHandler(async (req, res) => {
  const companies = await query('SELECT * FROM companies WHERE id = ?', [req.params.id]);
  if (!companies.length) return res.status(404).json({ error: 'Company not found.' });
  if (companies[0].owner_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'You can only edit your own company profile.' });
  }
  const { description, website, industry, location, logoUrl } = req.body;
  await query(
    `UPDATE companies SET description=COALESCE(?,description), website=COALESCE(?,website),
     industry=COALESCE(?,industry), location=COALESCE(?,location), logo_url=COALESCE(?,logo_url) WHERE id=?`,
    [description, website, industry, location, logoUrl, req.params.id]
  );
  res.json({ success: true });
}));

// Employer submits verification documents
router.post('/:id/verify', requireAuth, requireRole('employer'), asyncHandler(async (req, res) => {
  const { docsUrl } = req.body;
  await query(
    `UPDATE companies SET verification_status='pending', verification_docs_url=? WHERE id=? AND owner_id=?`,
    [docsUrl, req.params.id, req.user.id]
  );
  res.json({ success: true, message: 'Verification documents submitted for admin review.' });
}));

// Admin approves/rejects
router.put('/:id/verify-decision', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const { decision } = req.body; // 'verified' | 'rejected'
  if (!['verified', 'rejected'].includes(decision)) {
    return res.status(400).json({ error: 'Decision must be verified or rejected.' });
  }
  await query(
    `UPDATE companies SET verification_status=?, verified_at=NOW(), verified_by=? WHERE id=?`,
    [decision, req.user.id, req.params.id]
  );
  res.json({ success: true });
}));

export default router;
