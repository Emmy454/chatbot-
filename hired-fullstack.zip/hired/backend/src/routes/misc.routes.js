import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';

const router = Router();

// ---- Referrals ----
router.get('/referrals/mine', requireAuth, asyncHandler(async (req, res) => {
  const referrals = await query(
    `SELECT r.*, u.full_name, u.email FROM referrals r JOIN users u ON u.id = r.referred_id
     WHERE r.referrer_id = ? ORDER BY r.created_at DESC`,
    [req.user.id]
  );
  const users = await query('SELECT referral_code FROM users WHERE id = ?', [req.user.id]);
  res.json({ referrals, referralCode: users[0].referral_code });
}));

// ---- Job alert preferences ----
router.get('/alerts/mine', requireAuth, asyncHandler(async (req, res) => {
  const rows = await query('SELECT * FROM job_alert_preferences WHERE user_id = ?', [req.user.id]);
  res.json({ preference: rows[0] || null });
}));

router.put('/alerts/mine', requireAuth, asyncHandler(async (req, res) => {
  const { keywords, location, frequency } = req.body;
  const existing = await query('SELECT id FROM job_alert_preferences WHERE user_id = ?', [req.user.id]);
  if (existing.length) {
    await query(
      'UPDATE job_alert_preferences SET keywords=?, location=?, frequency=? WHERE user_id=?',
      [keywords, location, frequency || 'weekly', req.user.id]
    );
  } else {
    await query(
      'INSERT INTO job_alert_preferences (user_id, keywords, location, frequency) VALUES (?,?,?,?)',
      [req.user.id, keywords, location, frequency || 'weekly']
    );
  }
  res.json({ success: true });
}));

// ---- Admin dashboard summary ----
router.get('/admin/summary', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const [users] = await query('SELECT COUNT(*) c FROM users');
  const [jobs] = await query('SELECT COUNT(*) c FROM jobs WHERE status = "open"');
  const [flagged] = await query('SELECT COUNT(*) c FROM jobs WHERE status = "flagged"');
  const [pendingReviews] = await query('SELECT COUNT(*) c FROM reviews WHERE status = "pending"');
  const [openReports] = await query('SELECT COUNT(*) c FROM reports WHERE status = "open"');
  const [pendingCompanies] = await query('SELECT COUNT(*) c FROM companies WHERE verification_status = "pending"');
  res.json({
    totalUsers: users.c, openJobs: jobs.c, flaggedJobs: flagged.c,
    pendingReviews: pendingReviews.c, openReports: openReports.c, pendingCompanyVerifications: pendingCompanies.c,
  });
}));

export default router;
