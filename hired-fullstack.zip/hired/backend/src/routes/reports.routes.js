import { Router } from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';

const router = Router();
const AUTO_FLAG_THRESHOLD = 3;

router.post('/', requireAuth, asyncHandler(async (req, res) => {
  const { targetType, targetId, reason, details } = req.body;
  const validTypes = ['job', 'review', 'user', 'company'];
  if (!validTypes.includes(targetType)) return res.status(400).json({ error: 'Invalid report target type.' });

  await query(
    `INSERT INTO reports (reporter_id, target_type, target_id, reason, details) VALUES (?,?,?,?,?)`,
    [req.user.id, targetType, targetId, reason || 'other', details]
  );

  const countRows = await query(
    `SELECT COUNT(*) c FROM reports WHERE target_type = ? AND target_id = ? AND status = 'open'`,
    [targetType, targetId]
  );

  if (countRows[0].c >= AUTO_FLAG_THRESHOLD && targetType === 'job') {
    await query(`UPDATE jobs SET status = 'flagged' WHERE id = ?`, [targetId]);
  }

  res.status(201).json({ success: true, message: 'Thanks — our trust & safety team will review this within 24 hours.' });
}));

router.get('/', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const { status = 'open' } = req.query;
  const reports = await query(
    `SELECT r.*, u.full_name AS reporter_name FROM reports r JOIN users u ON u.id = r.reporter_id
     WHERE r.status = ? ORDER BY r.created_at DESC`,
    [status]
  );
  res.json({ reports });
}));

router.put('/:id/resolve', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const { status } = req.body; // reviewing | resolved | dismissed
  if (!['reviewing', 'resolved', 'dismissed'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status.' });
  }
  await query(
    'UPDATE reports SET status = ?, resolved_by = ?, resolved_at = NOW() WHERE id = ?',
    [status, req.user.id, req.params.id]
  );
  res.json({ success: true });
}));

export default router;
