import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { body, validationResult } from 'express-validator';
import passport from '../config/passport.js';
import { query } from '../config/db.js';
import { signToken, requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errorHandler.js';
import { generateReferralCode } from '../utils/helpers.js';

const router = Router();

function checkValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error(errors.array()[0].msg);
    err.status = 400;
    err.expose = true;
    throw err;
  }
}

function publicUser(user) {
  const { password_hash, ...rest } = user;
  return rest;
}

// ---- Register ----
router.post('/register', [
  body('fullName').trim().notEmpty().withMessage('Full name is required.'),
  body('email').isEmail().withMessage('A valid email is required.'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters.'),
  body('role').isIn(['candidate', 'employer']).withMessage('Role must be candidate or employer.'),
], asyncHandler(async (req, res) => {
  checkValidation(req);
  const { fullName, email, password, role, referralCode } = req.body;

  const existing = await query('SELECT id FROM users WHERE email = ?', [email]);
  if (existing.length) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const myReferralCode = generateReferralCode();

  let referredBy = null;
  if (referralCode) {
    const referrer = await query('SELECT id FROM users WHERE referral_code = ?', [referralCode]);
    if (referrer.length) referredBy = referrer[0].id;
  }

  const result = await query(
    `INSERT INTO users (full_name, email, password_hash, role, referral_code, referred_by)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [fullName, email, passwordHash, role, myReferralCode, referredBy]
  );

  if (role === 'candidate') {
    await query('INSERT INTO candidate_profiles (user_id) VALUES (?)', [result.insertId]);
  }

  if (referredBy) {
    await query(
      `INSERT INTO referrals (referrer_id, referred_id, status) VALUES (?, ?, 'pending')`,
      [referredBy, result.insertId]
    );
  }

  const users = await query('SELECT * FROM users WHERE id = ?', [result.insertId]);
  const token = signToken(users[0]);
  res.status(201).json({ token, user: publicUser(users[0]) });
}));

// ---- Login ----
router.post('/login', [
  body('email').isEmail(),
  body('password').notEmpty(),
], asyncHandler(async (req, res) => {
  checkValidation(req);
  const { email, password } = req.body;

  const users = await query('SELECT * FROM users WHERE email = ?', [email]);
  if (!users.length) return res.status(401).json({ error: 'Incorrect email or password.' });

  const user = users[0];
  if (user.password_hash.startsWith('oauth:')) {
    return res.status(400).json({ error: `This account was created with a social login. Please continue with that provider instead.` });
  }

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) return res.status(401).json({ error: 'Incorrect email or password.' });
  if (!user.is_active) return res.status(403).json({ error: 'This account has been deactivated.' });

  const token = signToken(user);
  res.json({ token, user: publicUser(user) });
}));

// ---- Current user ----
router.get('/me', requireAuth, asyncHandler(async (req, res) => {
  const users = await query('SELECT * FROM users WHERE id = ?', [req.user.id]);
  if (!users.length) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: publicUser(users[0]) });
}));

// ---- Google OAuth ----
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'], session: false }));

router.get('/google/callback',
  passport.authenticate('google', { session: false, failureRedirect: `${process.env.CLIENT_URL}/login?error=google` }),
  (req, res) => {
    const token = signToken(req.user);
    res.redirect(`${process.env.CLIENT_URL}/oauth-callback?token=${token}`);
  }
);

// ---- LinkedIn OAuth ----
router.get('/linkedin', passport.authenticate('linkedin', { session: false }));

router.get('/linkedin/callback',
  passport.authenticate('linkedin', { session: false, failureRedirect: `${process.env.CLIENT_URL}/login?error=linkedin` }),
  (req, res) => {
    const token = signToken(req.user);
    res.redirect(`${process.env.CLIENT_URL}/oauth-callback?token=${token}`);
  }
);

// ---- Indeed ----
// Indeed does not publish a general-purpose "Sign in with Indeed" OAuth flow for
// third-party sites, so a real login button here would be non-functional. We
// expose this endpoint to explain that clearly rather than silently failing.
router.get('/indeed', (req, res) => {
  res.status(501).json({
    error: 'Sign-in with Indeed is not available: Indeed does not offer a public OAuth login API for third-party job boards. Indeed integration in HirED is limited to job cross-posting (see jobs.source/external_url).',
  });
});

export default router;
