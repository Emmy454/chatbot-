// Google & LinkedIn OAuth strategies.
// Indeed does not currently offer a public OAuth "Sign in with Indeed" API for
// third-party job boards, so we surface an "Apply via Indeed" cross-post link
// instead (see jobs.source / jobs.external_url in schema.sql) rather than a
// fake login button that would silently fail.
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as LinkedInStrategy } from 'passport-linkedin-oauth2';
import dotenv from 'dotenv';
import { query } from './db.js';
import { generateReferralCode } from '../utils/helpers.js';

dotenv.config();

async function findOrCreateOAuthUser({ email, fullName, provider, providerId, avatarUrl }) {
  const existing = await query('SELECT * FROM users WHERE email = ?', [email]);
  if (existing.length) return existing[0];

  const referralCode = generateReferralCode();
  const result = await query(
    `INSERT INTO users (full_name, email, password_hash, role, avatar_url, is_verified, referral_code)
     VALUES (?, ?, ?, 'candidate', ?, TRUE, ?)`,
    [fullName, email, `oauth:${provider}:${providerId}`, avatarUrl || null, referralCode]
  );
  const created = await query('SELECT * FROM users WHERE id = ?', [result.insertId]);
  await query('INSERT INTO candidate_profiles (user_id) VALUES (?)', [result.insertId]);
  return created[0];
}

if (process.env.GOOGLE_CLIENT_ID) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/api/auth/google/callback',
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value;
      const user = await findOrCreateOAuthUser({
        email,
        fullName: profile.displayName,
        provider: 'google',
        providerId: profile.id,
        avatarUrl: profile.photos?.[0]?.value,
      });
      done(null, user);
    } catch (err) {
      done(err);
    }
  }));
}

if (process.env.LINKEDIN_CLIENT_ID) {
  passport.use(new LinkedInStrategy({
    clientID: process.env.LINKEDIN_CLIENT_ID,
    clientSecret: process.env.LINKEDIN_CLIENT_SECRET,
    callbackURL: '/api/auth/linkedin/callback',
    scope: ['r_emailaddress', 'r_liteprofile'],
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      const email = profile.emails?.[0]?.value;
      const user = await findOrCreateOAuthUser({
        email,
        fullName: profile.displayName,
        provider: 'linkedin',
        providerId: profile.id,
        avatarUrl: profile.photos?.[0]?.value,
      });
      done(null, user);
    } catch (err) {
      done(err);
    }
  }));
}

export default passport;
