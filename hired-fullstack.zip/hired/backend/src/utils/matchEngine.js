// Weighted skill / location / experience / history overlap scoring (0-100).
import { query } from '../config/db.js';
import { safeJsonParse } from './helpers.js';

const WEIGHTS = { skills: 0.5, location: 0.2, experience: 0.2, history: 0.1 };

const EXPERIENCE_ORDER = ['entry', 'junior', 'mid', 'senior', 'executive'];

function normalize(str = '') {
  return str.trim().toLowerCase();
}

function skillOverlapScore(candidateSkills = [], jobSkills = []) {
  if (!jobSkills.length) return 50; // neutral if job doesn't specify
  const cSet = new Set(candidateSkills.map(normalize));
  const matched = jobSkills.filter((s) => cSet.has(normalize(s)));
  return Math.round((matched.length / jobSkills.length) * 100);
}

function locationScore(candidateLocation, job) {
  if (job.is_remote) return 100;
  if (!candidateLocation || !job.location) return 40;
  if (normalize(candidateLocation) === normalize(job.location)) return 100;
  const cParts = normalize(candidateLocation).split(/[,\s]+/);
  const jParts = normalize(job.location).split(/[,\s]+/);
  return cParts.some((p) => jParts.includes(p)) ? 70 : 20;
}

function experienceScore(candidateLevel, jobLevel) {
  const cIdx = EXPERIENCE_ORDER.indexOf(candidateLevel);
  const jIdx = EXPERIENCE_ORDER.indexOf(jobLevel);
  if (cIdx === -1 || jIdx === -1) return 50;
  const diff = Math.abs(cIdx - jIdx);
  if (diff === 0) return 100;
  if (diff === 1) return 70;
  if (diff === 2) return 40;
  return 15;
}

async function historyScore(candidateId, job) {
  const applied = await query(
    `SELECT j.skills_required FROM applications a
     JOIN jobs j ON j.id = a.job_id
     WHERE a.candidate_id = ? ORDER BY a.applied_at DESC LIMIT 20`,
    [candidateId]
  );
  if (!applied.length) return 50;
  const jobSkills = new Set(safeJsonParse(job.skills_required).map(normalize));
  let overlapCount = 0;
  applied.forEach((row) => {
    const skills = safeJsonParse(row.skills_required).map(normalize);
    if (skills.some((s) => jobSkills.has(s))) overlapCount++;
  });
  return Math.round((overlapCount / applied.length) * 100);
}

export async function computeMatchScore(candidateProfile, job, candidateUserId) {
  const candidateSkills = safeJsonParse(candidateProfile?.skills);
  const jobSkills = safeJsonParse(job.skills_required);

  const sSkills = skillOverlapScore(candidateSkills, jobSkills);
  const sLocation = locationScore(candidateProfile?.location, job);
  const sExperience = experienceScore(candidateProfile?.experience_level, job.experience_level);
  const sHistory = candidateUserId ? await historyScore(candidateUserId, job) : 50;

  const total =
    sSkills * WEIGHTS.skills +
    sLocation * WEIGHTS.location +
    sExperience * WEIGHTS.experience +
    sHistory * WEIGHTS.history;

  return Math.round(total * 100) / 100;
}

// "Similar jobs" / "Because you viewed X" — skill + location overlap between jobs.
export async function findSimilarJobs(job, limit = 6) {
  const jobSkills = new Set(safeJsonParse(job.skills_required).map(normalize));
  const candidates = await query(
    `SELECT * FROM jobs WHERE id != ? AND status = 'open'
     AND (location = ? OR is_remote = TRUE) LIMIT 50`,
    [job.id, job.location]
  );

  const scored = candidates.map((c) => {
    const cSkills = safeJsonParse(c.skills_required).map(normalize);
    const overlap = cSkills.filter((s) => jobSkills.has(s)).length;
    const score = jobSkills.size ? overlap / jobSkills.size : 0;
    return { ...c, similarity: Math.round(score * 100) };
  });

  return scored.sort((a, b) => b.similarity - a.similarity).slice(0, limit);
}
