// Demo data seeder — run with `npm run seed` after schema.sql has been imported.
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { pool, query } from '../config/db.js';
import { generateReferralCode } from './helpers.js';

dotenv.config();

async function seed() {
  console.log('Seeding demo data...');
  const passwordHash = await bcrypt.hash('Password123', 10);

  // Admin
  const [existingAdmin] = await query('SELECT id FROM users WHERE email = ?', ['admin@hired.ng']);
  let adminId = existingAdmin?.id;
  if (!adminId) {
    const r = await query(
      `INSERT INTO users (full_name, email, password_hash, role, is_verified, referral_code)
       VALUES (?,?,?,?,TRUE,?)`,
      ['HirED Admin', 'admin@hired.ng', passwordHash, 'admin', generateReferralCode()]
    );
    adminId = r.insertId;
  }

  // Employer + company
  const [existingEmployer] = await query('SELECT id FROM users WHERE email = ?', ['hr@zenithdigital.ng']);
  let employerId = existingEmployer?.id;
  if (!employerId) {
    const r = await query(
      `INSERT INTO users (full_name, email, password_hash, role, is_verified, referral_code)
       VALUES (?,?,?,?,TRUE,?)`,
      ['Ngozi Adeyemi', 'hr@zenithdigital.ng', passwordHash, 'employer', generateReferralCode()]
    );
    employerId = r.insertId;
  }

  let [company] = await query('SELECT * FROM companies WHERE owner_id = ?', [employerId]);
  let companyId = company?.id;
  if (!companyId) {
    const r = await query(
      `INSERT INTO companies (owner_id, name, description, website, industry, location, verification_status, trust_score)
       VALUES (?,?,?,?,?,?,?,?)`,
      [employerId, 'Zenith Digital', 'A growing software studio building products for Nigerian SMEs.',
        'https://zenithdigital.ng', 'Software', 'Lagos, NG', 'verified', 88.5]
    );
    companyId = r.insertId;
  }

  // Candidate
  const [existingCandidate] = await query('SELECT id FROM users WHERE email = ?', ['chidera@student.futo.edu.ng']);
  let candidateId = existingCandidate?.id;
  if (!candidateId) {
    const r = await query(
      `INSERT INTO users (full_name, email, password_hash, role, referral_code)
       VALUES (?,?,?,?,?)`,
      ['Chidera Okafor', 'chidera@student.futo.edu.ng', passwordHash, 'candidate', generateReferralCode()]
    );
    candidateId = r.insertId;
    await query(
      `INSERT INTO candidate_profiles (user_id, headline, bio, location, experience_level, years_experience, skills)
       VALUES (?,?,?,?,?,?,?)`,
      [candidateId, 'Final-year Computer Science student', 'Aspiring full-stack developer from FUTO.',
        'Owerri, NG', 'entry', 0, JSON.stringify(['JavaScript', 'React', 'Node.js', 'SQL'])]
    );
  }

  // Sample jobs
  const [existingJobs] = await query('SELECT COUNT(*) c FROM jobs WHERE company_id = ?', [companyId]);
  if (existingJobs.c === 0) {
    const jobs = [
      ['Frontend Developer Intern', 'Work on our React product alongside senior engineers. Great mentorship and real production exposure.',
        JSON.stringify(['React', 'JavaScript', 'CSS']), 'Lagos, NG', false, 'internship', 'entry', 80000, 120000],
      ['Backend Engineer (Node.js)', 'Build and maintain REST APIs powering our core platform using Node.js, Express, and MySQL.',
        JSON.stringify(['Node.js', 'Express', 'MySQL']), 'Lagos, NG', true, 'full-time', 'junior', 250000, 400000],
      ['NYSC Corps Member - IT Support', 'Support internal IT operations during your service year. Open to corps members posted to Lagos.',
        JSON.stringify(['Troubleshooting', 'Networking']), 'Lagos, NG', false, 'nysc', 'entry', 50000, 60000],
    ];
    for (const [title, description, skills, location, isRemote, jobType, expLevel, salMin, salMax] of jobs) {
      await query(
        `INSERT INTO jobs (company_id, posted_by, title, description, skills_required, location, is_remote,
          job_type, experience_level, salary_min, salary_max, application_deadline, fraud_score)
         VALUES (?,?,?,?,?,?,?,?,?,?,?, DATE_ADD(NOW(), INTERVAL 30 DAY), 5.00)`,
        [companyId, employerId, title, description, skills, location, isRemote, jobType, expLevel, salMin, salMax]
      );
    }
  }

  console.log('Seed complete. Demo logins (password: Password123):');
  console.log('  Admin:     admin@hired.ng');
  console.log('  Employer:  hr@zenithdigital.ng');
  console.log('  Candidate: chidera@student.futo.edu.ng');
  await pool.end();
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
