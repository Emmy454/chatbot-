// Rule-based, explainable scam-risk scoring for job listings.
// Returns a 0-100 score plus a human-readable breakdown so admins (and
// eventually candidates, via the Trust Ring) can see *why* something was flagged.

const SCAM_PHRASES = [
  'wire transfer', 'processing fee', 'registration fee', 'training fee',
  'send money', 'western union', 'whatsapp only', 'no interview needed',
  'urgent hiring', 'guaranteed income', 'work from home no experience',
  'pay before you start', 'bank details required upfront',
];

const VAGUE_PHRASES = ['easy money', 'be your own boss', 'unlimited earning potential'];

export function scoreJobFraudRisk(job, company) {
  let score = 0;
  const reasons = [];

  const text = `${job.title} ${job.description} ${job.requirements || ''}`.toLowerCase();

  SCAM_PHRASES.forEach((phrase) => {
    if (text.includes(phrase)) {
      score += 20;
      reasons.push(`Contains a known scam-associated phrase: "${phrase}"`);
    }
  });

  VAGUE_PHRASES.forEach((phrase) => {
    if (text.includes(phrase)) {
      score += 8;
      reasons.push(`Vague/hype language: "${phrase}"`);
    }
  });

  if (!job.salary_min && !job.salary_max) {
    score += 5;
    reasons.push('No salary range provided');
  } else if (job.salary_max && job.salary_min && Number(job.salary_max) > Number(job.salary_min) * 10) {
    score += 15;
    reasons.push('Salary range is implausibly wide');
  }

  if (job.description && job.description.length < 80) {
    score += 15;
    reasons.push('Job description is unusually short/generic');
  }

  if (!company || company.verification_status !== 'verified') {
    score += 20;
    reasons.push('Posting company is not verified');
  }

  if (!company?.website) {
    score += 10;
    reasons.push('Company has no listed website');
  }

  if (job.application_deadline) {
    const days = (new Date(job.application_deadline) - new Date()) / (1000 * 60 * 60 * 24);
    if (days >= 0 && days < 1) {
      score += 10;
      reasons.push('Deadline is suspiciously immediate (urgency pressure tactic)');
    }
  }

  score = Math.max(0, Math.min(100, score));

  let level = 'low';
  if (score >= 70) level = 'high';
  else if (score >= 35) level = 'medium';

  return { score, level, reasons };
}

export const FRAUD_AUTO_FLAG_THRESHOLD = 70;
