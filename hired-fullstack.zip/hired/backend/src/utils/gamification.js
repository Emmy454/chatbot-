import { query } from '../config/db.js';
import { safeJsonParse } from './helpers.js';

// Profile completion % — weighted checklist.
export async function computeProfileCompletion(userId) {
  const users = await query('SELECT * FROM users WHERE id = ?', [userId]);
  const user = users[0];
  if (!user) return 0;

  if (user.role === 'candidate') {
    const profiles = await query('SELECT * FROM candidate_profiles WHERE user_id = ?', [userId]);
    const p = profiles[0] || {};
    const checks = [
      [!!user.avatar_url, 10],
      [!!user.phone, 5],
      [!!p.headline, 15],
      [!!p.bio, 15],
      [!!p.location, 10],
      [!!p.resume_url, 25],
      [safeJsonParse(p.skills).length > 0, 15],
      [!!p.linkedin_url || !!p.portfolio_url, 5],
    ];
    const pct = checks.reduce((sum, [ok, w]) => sum + (ok ? w : 0), 0);
    await query('UPDATE users SET profile_completion = ? WHERE id = ?', [pct, userId]);
    return pct;
  }

  return user.profile_completion;
}

const BADGE_RULES = [
  { code: 'PROFILE_COMPLETE', check: async (userId) => (await computeProfileCompletion(userId)) >= 100 },
  { code: 'FIRST_APPLICATION', check: async (userId) => {
      const rows = await query('SELECT COUNT(*) c FROM applications WHERE candidate_id = ?', [userId]);
      return rows[0].c >= 1;
    } },
  { code: 'FIVE_APPLICATIONS', check: async (userId) => {
      const rows = await query('SELECT COUNT(*) c FROM applications WHERE candidate_id = ?', [userId]);
      return rows[0].c >= 5;
    } },
  { code: 'FIRST_REVIEW', check: async (userId) => {
      const rows = await query('SELECT COUNT(*) c FROM reviews WHERE user_id = ?', [userId]);
      return rows[0].c >= 1;
    } },
  { code: 'VERIFIED_CANDIDATE', check: async (userId) => {
      const rows = await query('SELECT is_verified FROM users WHERE id = ?', [userId]);
      return !!rows[0]?.is_verified;
    } },
  { code: 'COMMUNITY_HELPER', check: async (userId) => {
      const rows = await query('SELECT COUNT(*) c FROM forum_replies WHERE user_id = ?', [userId]);
      return rows[0].c >= 1;
    } },
];

// Call this after any action that could unlock a badge (apply, review, profile save, etc).
export async function evaluateAndAwardBadges(userId) {
  const newlyAwarded = [];
  for (const rule of BADGE_RULES) {
    const earned = await rule.check(userId);
    if (!earned) continue;
    const badgeRows = await query('SELECT id FROM badges WHERE code = ?', [rule.code]);
    if (!badgeRows.length) continue;
    const result = await query(
      'INSERT IGNORE INTO user_badges (user_id, badge_id) VALUES (?, ?)',
      [userId, badgeRows[0].id]
    );
    if (result.affectedRows > 0) newlyAwarded.push(rule.code);
  }
  return newlyAwarded;
}
