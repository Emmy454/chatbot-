/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#0B1E33', 50: '#E8EDF2', 100: '#C7D3E0', 700: '#122A47', 900: '#0B1E33' },
        campus: { DEFAULT: '#1F7A5C', 50: '#E7F4EF', 100: '#C3E6D8', 500: '#1F7A5C', 600: '#186349', 700: '#124B38' },
        amber: { DEFAULT: '#F2A93B', 100: '#FDEFD6', 500: '#F2A93B', 600: '#D98F1F' },
        // Background is now pure white throughout the app (previously "parchment").
        surface: { DEFAULT: '#FFFFFF', muted: '#F8FAFC', border: '#E7EAEE' },
        slate: { DEFAULT: '#1C2530', 500: '#4B5563', 400: '#6B7280' },
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      borderRadius: { card: '14px' },
      boxShadow: {
        card: '0 1px 2px rgba(11,30,51,0.06), 0 8px 24px -8px rgba(11,30,51,0.10)',
        cardHover: '0 4px 12px rgba(11,30,51,0.08), 0 16px 40px -12px rgba(11,30,51,0.18)',
      },
    },
  },
  plugins: [],
};
