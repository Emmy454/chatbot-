import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send } from 'lucide-react';
import api from '../api/client';

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { sender: 'bot', message: "Hi! I'm the HirED assistant. Ask me about applying, verification, or reporting a scam." },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);
  const sessionId = useRef(`sess_${Date.now()}`);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, open]);

  const send = async () => {
    if (!input.trim()) return;
    const userMsg = { sender: 'user', message: input };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setSending(true);
    try {
      const { data } = await api.post('/chatbot/message', { message: userMsg.message, sessionId: sessionId.current });
      setMessages((m) => [...m, { sender: 'bot', message: data.answer }]);
    } catch {
      setMessages((m) => [...m, { sender: 'bot', message: "Sorry, I couldn't reach the server just now." }]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="mb-3 w-80 h-96 bg-white rounded-card shadow-cardHover border border-surface-border flex flex-col overflow-hidden"
          >
            <div className="bg-ink text-white px-4 py-3 flex items-center justify-between">
              <span className="font-medium text-sm">HirED Assistant</span>
              <button onClick={() => setOpen(false)}><X size={16} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2 scrollbar-thin">
              {messages.map((m, i) => (
                <div key={i} className={`max-w-[85%] px-3 py-2 rounded-lg text-sm ${
                  m.sender === 'user' ? 'bg-ink text-white ml-auto' : 'bg-ink-50 text-ink'
                }`}>
                  {m.message}
                </div>
              ))}
              {sending && <div className="text-xs text-slate-400 px-1">Typing…</div>}
              <div ref={bottomRef} />
            </div>
            <div className="p-2 border-t border-surface-border flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && send()}
                placeholder="Ask a question…"
                className="flex-1 text-sm px-3 py-2 rounded-lg border border-surface-border focus:outline-none focus:ring-2 focus:ring-campus-500"
              />
              <button onClick={send} className="bg-ink text-white rounded-lg px-3"><Send size={14} /></button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setOpen((o) => !o)}
        className="h-14 w-14 rounded-full bg-ink text-white shadow-cardHover flex items-center justify-center"
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </motion.button>
    </div>
  );
}
