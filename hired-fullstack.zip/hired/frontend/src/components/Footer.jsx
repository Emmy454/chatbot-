import { Link } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-surface-border mt-20">
      <div className="max-w-6xl mx-auto px-5 py-10 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
        <div className="col-span-2 md:col-span-1">
          <div className="flex items-center gap-2 font-display font-semibold text-ink mb-2">
            <span className="h-7 w-7 rounded-lg bg-ink flex items-center justify-center text-white">
              <GraduationCap size={16} />
            </span>
            HirED
          </div>
          <p className="text-slate-400">My Campus to Career.</p>
        </div>
        <div>
          <p className="font-medium text-ink mb-2">Explore</p>
          <ul className="space-y-1 text-slate-500">
            <li><Link to="/jobs">Find Jobs</Link></li>
            <li><Link to="/forum">Community</Link></li>
          </ul>
        </div>
        <div>
          <p className="font-medium text-ink mb-2">Trust & Safety</p>
          <ul className="space-y-1 text-slate-500">
            <li>Employer verification</li>
            <li>Scam detection</li>
            <li>Report a listing</li>
          </ul>
        </div>
        <div>
          <p className="font-medium text-ink mb-2">Account</p>
          <ul className="space-y-1 text-slate-500">
            <li><Link to="/login">Log in</Link></li>
            <li><Link to="/register">Sign up</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-surface-border py-4 text-center text-xs text-slate-400">
        © {new Date().getFullYear()} HirED — Final Year Project.
      </div>
    </footer>
  );
}
