import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, GraduationCap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const links = [
  { to: '/jobs', label: 'Find Jobs' },
  { to: '/forum', label: 'Community' },
  { to: '/dashboard', label: 'Dashboard', auth: true },
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-surface-border">
      <nav className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold text-ink">
          <span className="h-8 w-8 rounded-lg bg-ink flex items-center justify-center text-white">
            <GraduationCap size={18} />
          </span>
          HirED
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {links.filter((l) => !l.auth || user).map((l) => (
            <Link key={l.to} to={l.to} className="text-sm text-slate-500 hover:text-ink transition-colors">
              {l.label}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          {user ? (
            <>
              <span className="text-sm text-slate-500">Hi, {user.full_name.split(' ')[0]}</span>
              <button
                onClick={() => { logout(); navigate('/'); }}
                className="text-sm font-medium px-4 py-2 rounded-lg border border-surface-border hover:bg-ink-50 transition-colors"
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium text-ink hover:text-campus-600">Log in</Link>
              <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                <Link to="/register" className="text-sm font-medium text-white bg-ink px-4 py-2 rounded-lg hover:bg-ink-700 transition-colors">
                  Sign up
                </Link>
              </motion.div>
            </>
          )}
        </div>

        <button className="md:hidden text-ink" onClick={() => setOpen((o) => !o)} aria-label="Toggle menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden border-t border-surface-border bg-white"
          >
            <div className="px-5 py-4 flex flex-col gap-4">
              {links.filter((l) => !l.auth || user).map((l) => (
                <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="text-sm text-slate-600">
                  {l.label}
                </Link>
              ))}
              {user ? (
                <button onClick={() => { logout(); setOpen(false); navigate('/'); }} className="text-sm text-left text-slate-600">
                  Log out
                </button>
              ) : (
                <>
                  <Link to="/login" onClick={() => setOpen(false)} className="text-sm text-ink font-medium">Log in</Link>
                  <Link to="/register" onClick={() => setOpen(false)} className="text-sm text-white bg-ink px-4 py-2 rounded-lg text-center">Sign up</Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
