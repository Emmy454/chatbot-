import { motion } from 'framer-motion';

// Blends employer verification, average review rating, and inverse fraud-risk
// into one 0-100 gauge, per README's "Trust Ring" concept.
export default function TrustRing({ score = 0, size = 56, label, showLabel = true }) {
  const clamped = Math.max(0, Math.min(100, score));
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (clamped / 100) * circumference;

  const color = clamped >= 75 ? '#1F7A5C' : clamped >= 45 ? '#F2A93B' : '#D64545';

  return (
    <div className="flex items-center gap-2" title={label || `Trust score: ${clamped}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="#E7EAEE" strokeWidth="6" fill="none" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={radius}
          stroke={color} strokeWidth="6" fill="none" strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: 'easeOut' }}
        />
      </svg>
      {showLabel && (
        <div className="flex flex-col leading-tight">
          <span className="font-semibold text-ink text-sm">{Math.round(clamped)}%</span>
          <span className="text-xs text-slate-400">Trust</span>
        </div>
      )}
    </div>
  );
}
