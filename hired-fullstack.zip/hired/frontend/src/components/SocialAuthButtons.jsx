import { motion } from 'framer-motion';

// "Continue with Google/LinkedIn" hit the backend's OAuth redirect flow directly.
// Indeed has no public third-party OAuth login API, so that button is disabled
// with an honest explanation instead of silently failing at click time.
export default function SocialAuthButtons({ label = 'Continue' }) {
  const buttons = [
    {
      name: 'Google',
      href: '/api/auth/google',
      enabled: true,
      icon: (
        <svg width="18" height="18" viewBox="0 0 18 18"><path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.9c1.7-1.57 2.7-3.88 2.7-6.62Z"/><path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.9-2.26c-.8.54-1.84.86-3.06.86-2.35 0-4.34-1.59-5.05-3.72H.94v2.33A9 9 0 0 0 9 18Z"/><path fill="#FBBC05" d="M3.95 10.7A5.4 5.4 0 0 1 3.66 9c0-.59.1-1.16.29-1.7V4.97H.94A9 9 0 0 0 0 9c0 1.45.35 2.83.94 4.03l3.01-2.33Z"/><path fill="#EA4335" d="M9 3.58c1.32 0 2.5.46 3.44 1.35l2.58-2.58A8.99 8.99 0 0 0 9 0 9 9 0 0 0 .94 4.97l3.01 2.33C4.66 5.17 6.65 3.58 9 3.58Z"/></svg>
      ),
    },
    {
      name: 'LinkedIn',
      href: '/api/auth/linkedin',
      enabled: true,
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#0A66C2"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.48-.9 1.63-1.85 3.36-1.85 3.59 0 4.25 2.36 4.25 5.44v6.3ZM5.34 7.43a2.06 2.06 0 1 1 0-4.12 2.06 2.06 0 0 1 0 4.12ZM7.12 20.45H3.56V9h3.56v11.45Z"/></svg>
      ),
    },
    {
      name: 'Indeed',
      href: '#',
      enabled: false,
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#2557A7"><path d="M12.02 5.9a2.1 2.1 0 1 1 0-4.2 2.1 2.1 0 0 1 0 4.2Zm1.7 15.4c-.6.4-1.5.7-2.5.7-1.7 0-2.6-1-2.6-2.9V9.4h3.2v9.3c0 .5.2.7.6.7.3 0 .6-.1.9-.3l.4 2.2Z"/></svg>
      ),
    },
  ];

  return (
    <div className="flex flex-col gap-2">
      {buttons.map((b, i) => (
        <motion.a
          key={b.name}
          href={b.enabled ? b.href : undefined}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
          whileHover={b.enabled ? { scale: 1.015 } : {}}
          whileTap={b.enabled ? { scale: 0.98 } : {}}
          title={!b.enabled ? 'Indeed does not offer a public sign-in API for third-party sites' : undefined}
          className={`flex items-center justify-center gap-2 border border-surface-border rounded-lg py-2.5 text-sm font-medium transition-colors
            ${b.enabled ? 'text-ink hover:bg-ink-50 cursor-pointer' : 'text-slate-400 cursor-not-allowed opacity-60'}`}
        >
          {b.icon}
          {label} with {b.name}
          {!b.enabled && <span className="text-xs">(unavailable)</span>}
        </motion.a>
      ))}
    </div>
  );
}
