import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { MapPin, Briefcase, Sparkles, BadgeCheck } from 'lucide-react';
import TrustRing from './TrustRing';

export default function JobCard({ job, index = 0 }) {
  const trust = Math.round(
    (job.verification_status === 'verified' ? 60 : 20) + Math.max(0, 40 - (job.fraud_score || 0) * 0.4)
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.35, delay: Math.min(index, 6) * 0.05 }}
      whileHover={{ y: -4 }}
      className="group bg-white border border-surface-border rounded-card shadow-card hover:shadow-cardHover transition-shadow p-5 flex flex-col gap-3"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-lg bg-ink-50 flex items-center justify-center overflow-hidden shrink-0">
            {job.company_logo
              ? <img src={job.company_logo} alt="" className="h-full w-full object-cover" />
              : <Briefcase size={18} className="text-ink-700" />}
          </div>
          <div>
            <Link to={`/jobs/${job.id}`} className="font-display font-semibold text-ink group-hover:text-campus-600 transition-colors">
              {job.title}
            </Link>
            <p className="text-sm text-slate-500 flex items-center gap-1">
              {job.company_name}
              {job.verification_status === 'verified' && <BadgeCheck size={14} className="text-campus-600" />}
            </p>
          </div>
        </div>
        {job.is_featured ? (
          <span className="flex items-center gap-1 text-xs font-medium text-amber-600 bg-amber-100 px-2 py-1 rounded-full">
            <Sparkles size={12} /> Featured
          </span>
        ) : (
          <TrustRing score={trust} size={40} showLabel={false} />
        )}
      </div>

      <p className="text-sm text-slate-500 line-clamp-2">{job.description}</p>

      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1">
        <span className="flex items-center gap-1"><MapPin size={12} /> {job.is_remote ? 'Remote' : job.location}</span>
        <span className="px-2 py-0.5 rounded-full bg-ink-50 text-ink-700 capitalize">{job.job_type}</span>
        <span className="px-2 py-0.5 rounded-full bg-ink-50 text-ink-700 capitalize">{job.experience_level}</span>
      </div>

      <div className="flex items-center justify-between mt-2">
        <span className="text-sm font-medium text-ink">
          {job.salary_min ? `₦${Number(job.salary_min).toLocaleString()} - ₦${Number(job.salary_max).toLocaleString()}` : 'Salary not disclosed'}
        </span>
        <Link to={`/jobs/${job.id}`} className="text-sm font-medium text-campus-600 hover:text-campus-700">
          View →
        </Link>
      </div>
    </motion.div>
  );
}
