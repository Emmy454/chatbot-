import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, SlidersHorizontal } from 'lucide-react';
import api from '../api/client';
import JobCard from '../components/JobCard';

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', location: '', jobType: '', experienceLevel: '', remote: '' });
  const [showFilters, setShowFilters] = useState(false);

  const fetchJobs = async () => {
    setLoading(true);
    const params = Object.fromEntries(Object.entries(filters).filter(([, v]) => v));
    try {
      const { data } = await api.get('/jobs', { params });
      setJobs(data.jobs);
    } catch {
      setJobs([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchJobs(); /* eslint-disable-next-line */ }, []);

  return (
    <div className="max-w-6xl mx-auto px-5 py-10">
      <h1 className="font-display text-3xl font-semibold text-ink mb-6">Find your next role</h1>

      <form onSubmit={(e) => { e.preventDefault(); fetchJobs(); }} className="flex flex-col md:flex-row gap-3 mb-4">
        <div className="flex-1 flex items-center gap-2 border border-surface-border rounded-lg px-3 bg-white">
          <Search size={16} className="text-slate-400" />
          <input
            value={filters.search}
            onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
            placeholder="Job title, keyword…"
            className="w-full py-2.5 text-sm focus:outline-none"
          />
        </div>
        <input
          value={filters.location}
          onChange={(e) => setFilters((f) => ({ ...f, location: e.target.value }))}
          placeholder="Location"
          className="border border-surface-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-campus-500"
        />
        <button type="button" onClick={() => setShowFilters((s) => !s)}
          className="flex items-center gap-2 border border-surface-border rounded-lg px-4 py-2.5 text-sm font-medium hover:bg-ink-50">
          <SlidersHorizontal size={14} /> Filters
        </button>
        <motion.button whileTap={{ scale: 0.97 }} type="submit"
          className="bg-ink text-white rounded-lg px-6 py-2.5 text-sm font-medium hover:bg-ink-700">
          Search
        </motion.button>
      </form>

      {showFilters && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
          className="flex flex-wrap gap-3 mb-6 overflow-hidden">
          <select value={filters.jobType} onChange={(e) => setFilters((f) => ({ ...f, jobType: e.target.value }))}
            className="border border-surface-border rounded-lg px-3 py-2 text-sm">
            <option value="">Any job type</option>
            <option value="internship">Internship</option>
            <option value="part-time">Part-time</option>
            <option value="full-time">Full-time</option>
            <option value="contract">Contract</option>
            <option value="nysc">NYSC</option>
          </select>
          <select value={filters.experienceLevel} onChange={(e) => setFilters((f) => ({ ...f, experienceLevel: e.target.value }))}
            className="border border-surface-border rounded-lg px-3 py-2 text-sm">
            <option value="">Any experience level</option>
            <option value="entry">Entry</option>
            <option value="junior">Junior</option>
            <option value="mid">Mid</option>
            <option value="senior">Senior</option>
          </select>
          <label className="flex items-center gap-2 text-sm border border-surface-border rounded-lg px-3 py-2">
            <input type="checkbox" checked={filters.remote === 'true'}
              onChange={(e) => setFilters((f) => ({ ...f, remote: e.target.checked ? 'true' : '' }))} />
            Remote only
          </label>
        </motion.div>
      )}

      {loading ? (
        <p className="text-slate-400">Loading jobs…</p>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {jobs.map((job, i) => <JobCard key={job.id} job={job} index={i} />)}
          {!jobs.length && <p className="text-slate-400 col-span-full">No jobs match those filters yet.</p>}
        </div>
      )}
    </div>
  );
}
