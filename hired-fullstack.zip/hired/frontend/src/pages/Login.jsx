import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import SocialAuthButtons from '../components/SocialAuthButtons';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-5 py-16">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-surface-border rounded-card shadow-card p-8">
        <h1 className="font-display text-2xl font-semibold text-ink mb-1">Welcome back</h1>
        <p className="text-slate-500 text-sm mb-6">Log in to continue your job search.</p>

        <SocialAuthButtons label="Log in" />
        <div className="flex items-center gap-3 my-5 text-xs text-slate-400">
          <div className="h-px bg-surface-border flex-1" /> OR <div className="h-px bg-surface-border flex-1" />
        </div>

        <form onSubmit={submit} className="flex flex-col gap-3">
          <input required type="email" placeholder="Email" value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            className="border border-surface-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-campus-500" />
          <input required type="password" placeholder="Password" value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            className="border border-surface-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-campus-500" />
          <motion.button whileTap={{ scale: 0.97 }} disabled={loading} type="submit"
            className="bg-ink text-white rounded-lg py-2.5 text-sm font-medium hover:bg-ink-700 disabled:opacity-60">
            {loading ? 'Logging in…' : 'Log in'}
          </motion.button>
        </form>

        <p className="text-sm text-slate-500 mt-5 text-center">
          Don't have an account? <Link to="/register" className="text-campus-600 font-medium">Sign up</Link>
        </p>
      </motion.div>
    </div>
  );
}
