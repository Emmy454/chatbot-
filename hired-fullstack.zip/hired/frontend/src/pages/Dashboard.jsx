import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Award, FileText, Building2 } from 'lucide-react';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [badges, setBadges] = useState([]);
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    api.get('/users/me/profile').then(({ data }) => { setProfile(data.profile); setBadges(data.badges); });
    if (user?.role === 'candidate') {
      api.get('/applications/mine').then(({ data }) => setApplications(data.applications));
    }
  }, [user]);

  return (
    <div className="max-w-5xl mx-auto px-5 py-10">
      <h1 className="font-display text-3xl font-semibold text-ink mb-1">Welcome, {user?.full_name?.split(' ')[0]}</h1>
      <p className="text-slate-500 mb-8 capitalize">{user?.role} account</p>

      <div className="grid md:grid-cols-3 gap-5">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-surface-border rounded-card shadow-card p-5 md:col-span-1">
          <p className="text-sm text-slate-500 mb-2">Profile completion</p>
          <div className="h-3 bg-ink-50 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-campus-500"
              initial={{ width: 0 }}
              animate={{ width: `${user?.profile_completion || 0}%` }}
              transition={{ duration: 0.8 }}
            />
          </div>
          <p className="text-xs text-slate-400 mt-2">{user?.profile_completion || 0}% complete</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
          className="bg-white border border-surface-border rounded-card shadow-card p-5">
          <p className="text-sm text-slate-500 mb-3 flex items-center gap-2"><Award size={14} /> Badges earned</p>
          <div className="flex flex-wrap gap-2">
            {badges.length ? badges.map((b) => (
              <span key={b.id} className="text-xs bg-amber-100 text-amber-600 px-2 py-1 rounded-full">{b.name}</span>
            )) : <p className="text-xs text-slate-400">None yet — apply to a job or complete your profile.</p>}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-white border border-surface-border rounded-card shadow-card p-5">
          <p className="text-sm text-slate-500 mb-3 flex items-center gap-2">
            {user?.role === 'candidate' ? <FileText size={14} /> : <Building2 size={14} />}
            {user?.role === 'candidate' ? 'Applications' : 'Company'}
          </p>
          <p className="text-2xl font-display font-semibold text-ink">
            {user?.role === 'candidate' ? applications.length : '—'}
          </p>
        </motion.div>
      </div>

      {user?.role === 'candidate' && (
        <div className="mt-10">
          <h2 className="font-display text-xl font-semibold text-ink mb-4">My applications</h2>
          <div className="bg-white border border-surface-border rounded-card shadow-card divide-y divide-surface-border">
            {applications.length ? applications.map((a) => (
              <div key={a.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-ink">{a.title}</p>
                  <p className="text-sm text-slate-500">{a.company_name} · {a.location}</p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-ink-50 text-ink-700 capitalize">{a.status}</span>
              </div>
            )) : <p className="p-4 text-sm text-slate-400">You haven't applied to any jobs yet.</p>}
          </div>
        </div>
      )}

      {profile && (
        <div className="mt-10">
          <h2 className="font-display text-xl font-semibold text-ink mb-4">Profile</h2>
          <div className="bg-white border border-surface-border rounded-card shadow-card p-5 text-sm text-slate-600 space-y-1">
            <p><b>Headline:</b> {profile.headline || '—'}</p>
            <p><b>Location:</b> {profile.location || '—'}</p>
            <p><b>Experience:</b> {profile.experience_level}</p>
            <p><b>Skills:</b> {profile.skills?.join(', ') || '—'}</p>
          </div>
        </div>
      )}
    </div>
  );
}
