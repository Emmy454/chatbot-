import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function OAuthCallback() {
  const [params] = useSearchParams();
  const { loginWithToken } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const token = params.get('token');
    if (!token) { navigate('/login?error=oauth'); return; }
    loginWithToken(token).then(() => navigate('/dashboard')).catch(() => navigate('/login?error=oauth'));
    // eslint-disable-next-line
  }, []);

  return <div className="min-h-[50vh] flex items-center justify-center text-slate-400">Signing you in…</div>;
}
