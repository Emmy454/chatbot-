import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { MapPin, Briefcase, Clock, BadgeCheck, Flag, Bookmark } from 'lucide-react';
import api from '../api/client';
import TrustRing from '../components/TrustRing';
import JobCard from '../components/JobCard';
import { useAuth } from '../context/AuthContext';

export default function JobDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [job, setJob] = useState(null);
  const [similar, setSimilar] = useState([]);
  const [coverLetter, setCoverLetter] = useState('');
  const [applying, setApplying] = useState(false);

  useEffect(() => {
    api.get(`/jobs/${id}`).then(({ data }) => { setJob(data.job); setSimilar(data.similarJobs); });
  }, [id]);

  const apply = async () => {
    if (!user) return toast.error('Please log in as a candidate to apply.');
    setApplying(true);
    try {
      await api.post('/applications', { jobId: id, coverLetter });
      toast.success('Application submitted!');
      setCoverLetter('');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Could not submit application.');
    } finally {
      setApplying(false);
    }
  };

  const save = async () => {
    if (!user) return toast.error('Please log in to save jobs.');
    try { await api.post(`/jobs/${id}/save`); toast.success('Saved to your list.'); }
    catch { toast.error('Could not save this job.'); }
  };

  const report = async () => {
    if (!user) return toast.error('Please log in to report a listing.');
    try {
      await api.post('/reports', { targetType: 'job', targetId: id, reason: 'scam', details: 'Reported from job detail page.' });
      toast.success('Report submitted — thank you.');
    } catch { toast.error('Could not submit report.'); }
  };

  if (!job) return <div className="max-w-4xl mx-auto px-5 py-16 text-slate-400">Loading…</div>;

  const trust = Math.round(
    (job.verification_status === 'verified' ? 60 : 20) + Math.max(0, 40 - (job.fraud_score || 0) * 0.4)
  );

  return (
    <div className="max-w-4xl mx-auto px-5 py-10">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-surface-border rounded-card shadow-card p-6 md:p-8">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="font-display text-2xl md:text-3xl font-semibold text-ink">{job.title}</h1>
            <p className="text-slate-500 mt-1 flex items-center gap-2">
              {job.company_name}
              {job.verification_status === 'verified' && <BadgeCheck size={16} className="text-campus-600" />}
            </p>
          </div>
          <TrustRing score={trust} />
        </div>

        <div className="flex flex-wrap gap-3 mt-5 text-sm text-slate-500">
          <span className="flex items-center gap-1"><MapPin size={14} /> {job.is_remote ? 'Remote' : job.location}</span>
          <span className="flex items-center gap-1"><Briefcase size={14} /> {job.job_type}</span>
          {job.application_deadline && (
            <span className="flex items-center gap-1"><Clock size={14} /> Apply by {new Date(job.application_deadline).toLocaleDateString()}</span>
          )}
        </div>

        <p className="text-ink mt-6 whitespace-pre-line leading-relaxed">{job.description}</p>
        {job.requirements && (
          <>
            <h3 className="font-display font-semibold text-ink mt-6 mb-2">Requirements</h3>
            <p className="text-slate-600 whitespace-pre-line">{job.requirements}</p>
          </>
        )}

        <div className="flex gap-3 mt-6">
          <button onClick={save} className="flex items-center gap-2 border border-surface-border rounded-lg px-4 py-2 text-sm font-medium hover:bg-ink-50">
            <Bookmark size={14} /> Save
          </button>
          <button onClick={report} className="flex items-center gap-2 border border-surface-border rounded-lg px-4 py-2 text-sm font-medium text-red-500 hover:bg-red-50">
            <Flag size={14} /> Report
          </button>
        </div>

        {user?.role === 'candidate' && (
          <div className="mt-8 border-t border-surface-border pt-6">
            <h3 className="font-display font-semibold text-ink mb-3">Apply for this role</h3>
            <textarea
              value={coverLetter} onChange={(e) => setCoverLetter(e.target.value)}
              placeholder="Add a short cover letter (optional)…"
              rows={4}
              className="w-full border border-surface-border rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-campus-500"
            />
            <motion.button whileTap={{ scale: 0.97 }} disabled={applying} onClick={apply}
              className="mt-3 bg-ink text-white rounded-lg px-6 py-2.5 text-sm font-medium hover:bg-ink-700 disabled:opacity-60">
              {applying ? 'Submitting…' : 'Submit application'}
            </motion.button>
          </div>
        )}
      </motion.div>

      {!!similar.length && (
        <div className="mt-10">
          <h2 className="font-display text-xl font-semibold text-ink mb-4">Similar jobs</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {similar.map((j, i) => <JobCard key={j.id} job={j} index={i} />)}
          </div>
        </div>
      )}
    </div>
  );
}
