import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShieldCheck, Sparkles, Users, ArrowRight } from 'lucide-react';
import api from '../api/client';
import JobCard from '../components/JobCard';

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  show: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.5, ease: 'easeOut' } }),
};

export default function Home() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    api.get('/jobs?limit=6').then(({ data }) => setJobs(data.jobs)).catch(() => {});
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-5 pt-16 pb-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <motion.p variants={fadeUp} initial="hidden" animate="show" className="text-campus-600 font-medium text-sm mb-3">
            My Campus to Career
          </motion.p>
          <motion.h1 variants={fadeUp} initial="hidden" animate="show" custom={1} className="font-display text-4xl md:text-5xl font-semibold text-ink leading-tight">
            Find opportunities you can actually trust.
          </motion.h1>
          <motion.p variants={fadeUp} initial="hidden" animate="show" custom={2} className="text-slate-500 mt-5 text-lg">
            HirED verifies employers, scores scam-risk on every listing, and matches you to roles that fit your skills — built for students and NYSC corps members.
          </motion.p>
          <motion.div variants={fadeUp} initial="hidden" animate="show" custom={3} className="flex flex-wrap gap-3 mt-8">
            <Link to="/jobs" className="bg-ink text-white px-6 py-3 rounded-lg font-medium flex items-center gap-2 hover:bg-ink-700 transition-colors">
              Browse jobs <ArrowRight size={16} />
            </Link>
            <Link to="/register" className="border border-surface-border px-6 py-3 rounded-lg font-medium hover:bg-ink-50 transition-colors">
              Create an account
            </Link>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="grid gap-4"
        >
          {[
            { icon: ShieldCheck, title: 'Verified employers', desc: 'Every company completes a documented verification workflow before posting.' },
            { icon: Sparkles, title: 'AI-assisted matching', desc: 'Skill, location, and experience overlap scoring surfaces your best-fit roles.' },
            { icon: Users, title: 'Community-backed', desc: 'Forums, reviews, and reports keep the platform honest.' },
          ].map((f, i) => (
            <motion.div key={f.title} custom={i} variants={fadeUp} initial="hidden" animate="show"
              className="bg-white border border-surface-border rounded-card shadow-card p-5 flex gap-4 items-start">
              <div className="h-10 w-10 rounded-lg bg-campus-50 text-campus-600 flex items-center justify-center shrink-0">
                <f.icon size={18} />
              </div>
              <div>
                <p className="font-medium text-ink">{f.title}</p>
                <p className="text-sm text-slate-500">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Latest jobs */}
      <section className="max-w-6xl mx-auto px-5 pb-24">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-semibold text-ink">Latest opportunities</h2>
          <Link to="/jobs" className="text-sm font-medium text-campus-600 hover:text-campus-700">See all →</Link>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {jobs.map((job, i) => <JobCard key={job.id} job={job} index={i} />)}
          {!jobs.length && <p className="text-slate-400 col-span-full">No jobs yet — seed the database or post the first one.</p>}
        </div>
      </section>
    </div>
  );
}
