import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react';
import api from '../api/client';

export default function Forum() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    api.get('/forum/categories').then(({ data }) => setCategories(data.categories)).catch(() => {});
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-5 py-10">
      <h1 className="font-display text-3xl font-semibold text-ink mb-2">Community</h1>
      <p className="text-slate-500 mb-8">Interview tips, resume help, and career advice from fellow students.</p>

      <div className="grid md:grid-cols-2 gap-4">
        {categories.map((c, i) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            whileHover={{ y: -3 }}
            className="bg-white border border-surface-border rounded-card shadow-card p-5 cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-campus-50 text-campus-600 flex items-center justify-center">
                <MessageSquare size={16} />
              </div>
              <div>
                <p className="font-medium text-ink">{c.name}</p>
                <p className="text-sm text-slate-500">{c.description}</p>
              </div>
            </div>
          </motion.div>
        ))}
        {!categories.length && <p className="text-slate-400">No categories yet — seed the database to see demo content.</p>}
      </div>
    </div>
  );
}
